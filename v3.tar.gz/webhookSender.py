import requests
from discord import Webhook, RequestsWebhookAdapter

WEBHOOK_URL = ""
MY_WEBHOOK = Webhook.from_url("")

def initializeWebhook(TARGET_WEBHOOK_URL):
    WEBHOOK_URL = TARGET_WEBHOOK_URL
    MY_WEBHOOK = Webhook.from_url(WEBHOOK_URL)

def sendMsg(stringMessage):
    MY_WEBHOOK.send(stringMessage)
